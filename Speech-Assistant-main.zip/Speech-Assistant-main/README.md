# Speech-Assistant
In this video I've build a speech assistant program using the speech regonition library and Google's text-to-speech API. 

Building a Virtual Personal Assistant in Python is fairly easy and can be done by almost anyone who is willing to put in a little bit of effort.

Hope you'll enjoy it.
